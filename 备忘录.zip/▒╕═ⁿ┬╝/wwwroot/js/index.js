$('#createDir').click(function(){
    var dirName = prompt("新建文件夹","请输入您要创建的文件夹");
    if (dirName) {
        // 保存文件夹
        $.get('/api/createdir',"dirname="+dirName,(data)=>{
            alert(data.message);
            if (data.code == "success") {
                location.href = '/';
            }
        })
    }
})