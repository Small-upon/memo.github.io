const exp = require('express');
const fs = require('fs');
const route = exp.Router();

route.get('/notes/file/new/:path',function(req,res){
    var path = req.params.path;
    res.render('new',{path:path});
})

route.post('/notes/file/new',(req,res)=>{
    var path = req.body.path;
    var content = req.body.content;
    if (!!content) {
        path = `notes/${path}/${new Date().getTime()}.txt`;
        console.log(path);
        fs.writeFileSync(path,content);
    }
    res.json({
        code:"success",
        message:"创建备忘录成功"
    })
})
route.get('/notes/file/:path/:fileName',(req,res)=>{
    var path = req.params.path;
    var fileName = req.params.fileName;
    var content = fs.readFileSync(`notes/${path}/${fileName}`).toString();
    res.render('edite',{path:path,fileName:fileName,content:content});
})
route.post('/notes/file/editor',(req,res)=>{
    var fileName = req.body.fileName;
    var path = req.body.path;
    var content = req.body.content;
    path = `notes/${path}/${fileName}`;
    fs.writeFileSync(path,content);
    res.json({code:"success",message:"修改文件成功"});
})
module.exports = route;