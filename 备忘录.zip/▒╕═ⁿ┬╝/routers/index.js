const exp = require('express');
const fs = require('fs');
const route = exp.Router();

route.get('/', function (req, res) {
    var allDirs = fs.readdirSync('notes');
    var dirArr = [];
    for (var i = 0; i < allDirs.length; i++) {
        var fileStat = fs.statSync(`notes/${allDirs[i]}`);
        if (fileStat.isDirectory) {
            var dir = {};
            dir.dirName = allDirs[i];
            dir.fileCount = fs.readdirSync(`notes/${allDirs[i]}`).length;
            dirArr.push(dir);
        }
    }

    res.render('index', {
        list: dirArr
    })
})

route.get('/api/createdir', function (req, res) {
    function createDir() {
        fs.mkdir(`notes/${req.query.dirname}`, (err) => {
            if (err) {
                res.status(200).json({
                    code: "error",
                    message: "创建文件夹失败"
                })
            } else {
                res.status(200).json({
                    code: "success",
                    message: "创建文件夹成功"
                })
            }
        })
    }
    if (!!req.query.dirname.trim()) {
        fs.exists('notes', (exists) => {
            if (exists) {
                createDir();
            } else {
                fs.mkdir('notes', (err) => {
                    if (err) {
                        res.status(200).json({
                            code: "error",
                            message: "创建文件夹失败"
                        })
                    } else {
                        createDir();
                    }
                })
            }
        })
    }
})

route.get('/notes/:path',(req,res)=>{
    // 获取path参数
    var path = req.params.path;
    var arrFiles = fs.readdirSync(`notes/${path}`);
    var fileArr = [];
    for (var i = 0; i < arrFiles.length; i++) {
        var content = fs.readFileSync(`notes/${path}/${arrFiles[i]}`).toString();
        content = content.length>20?content.substr(0,18)+'...':content;
        fileArr.push({fileName:arrFiles[i],content:content});
    }
    res.render('fileAll',{path:path,files:fileArr});
})

module.exports = route;