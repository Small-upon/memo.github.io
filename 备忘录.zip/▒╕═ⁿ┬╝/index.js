const exp = require('express');
const bodyParser = require('body-parser');
const app = exp();

app.use(exp.static('wwwroot'));
app.use(bodyParser.urlencoded({extended:true}));

app.engine('html', require('express-art-template'));
app.set("view engine","html");
app.set('view options', {
    debug: process.env.NODE_ENV !== 'production'
});

app.use(require('./routers/index'));
app.use(require('./routers/file'));

app.listen(3000, function () {
    console.log('server on 3000...');
})